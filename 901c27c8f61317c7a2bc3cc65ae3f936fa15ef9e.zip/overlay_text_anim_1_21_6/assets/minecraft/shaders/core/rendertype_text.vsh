#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

vec3 loop2(vec3 a, vec3 b, float t) {
    float p = fract(t) * 2.0;
    return p < 1.0 ? mix(a, b, p) : mix(b, a, p - 1.0);
}

vec3 loop3(vec3 a, vec3 b, vec3 c, float t) {
    float p = fract(t) * 3.0;
    if (p < 1.0) return mix(a, b, p);
    if (p < 2.0) return mix(b, c, p - 1.0);
    return mix(c, a, p - 2.0);
}

vec3 animatedColor(int id, float t) {
    if (id == 1) return hsv2rgb(vec3(fract(t), 0.85, 1.00));
    if (id == 2) return loop2(vec3(0.0000, 0.9412, 1.0000), vec3(1.0000, 0.0000, 0.8980), t);
    if (id == 3) return loop3(vec3(1.0000, 0.1647, 0.0000), vec3(1.0000, 0.6039, 0.0000), vec3(1.0000, 0.8824, 0.3020), t);
    if (id == 4) return loop3(vec3(1.0000, 1.0000, 1.0000), vec3(0.6078, 0.9059, 1.0000), vec3(0.2471, 0.6627, 1.0000), t);
    if (id == 5) return loop3(vec3(0.5412, 0.1686, 0.8863), vec3(1.0000, 0.4314, 0.7804), vec3(1.0000, 0.8431, 0.4314), t);
    if (id == 6) return loop3(vec3(0.7843, 0.5882, 0.1176), vec3(1.0000, 0.8863, 0.4784), vec3(1.0000, 1.0000, 1.0000), t);
    if (id == 7) return loop3(vec3(0.4824, 0.1843, 0.9686), vec3(0.7843, 0.4275, 0.8431), vec3(0.0000, 0.8314, 1.0000), t);
    if (id == 8) return loop3(vec3(0.2235, 1.0000, 0.0784), vec3(0.7137, 1.0000, 0.0000), vec3(0.0000, 1.0000, 0.6118), t);
    if (id == 9) return loop3(vec3(0.5451, 0.0000, 0.0000), vec3(1.0000, 0.1255, 0.1255), vec3(1.0000, 0.4824, 0.4824), t);
    if (id == 10) return loop3(vec3(0.8784, 1.0000, 0.9804), vec3(0.4314, 0.9059, 0.8471), vec3(0.1216, 0.6353, 0.6353), t);
    if (id == 11) return hsv2rgb(vec3(fract(t), 0.45, 1.00));
    if (id == 12) return loop3(vec3(1.0000, 1.0000, 1.0000), vec3(1.0000, 0.9490, 0.0000), vec3(0.0000, 0.7020, 1.0000), t);
    return vec3(1.0);
}

vec4 animateMarked(vec4 color, vec4 clipPos) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    int id = c.b & 15;
    // GEÄNDERT (Bugfix 2026-10-16, gemeldet "Bugs bei Blood Moon" - gelbe/orange Flecken an einzelnen Buchstaben): der
    // Textschatten (Farbe x 0,25) traf bei ~2-15 % der Buchstaben zufällig selbst die Markierung, oft mit einer anderen
    // Stil-ID, und wurde dann bunt gefärbt. Schatten haben je Kanal höchstens 63, echte markierte Farben immer einen
    // Kanal >= 64 (alle Stil-Farben sind hell genug) - deshalb nur noch darüber.
    if ((c.r & 15) == 10 && (c.g & 15) == 5 && id >= 1 && id <= 12 && max(c.r, max(c.g, c.b)) >= 64) {
        float phase = fract(GameTime * 1200.0 / 3.0);
        float x = clipPos.x / max(clipPos.w, 0.0001);
        color.rgb = animatedColor(id, x * 1.5 - phase);
    }
    return color;
}

const float FLY_SIZE = 13.0;
// GEÄNDERT (Wunsch 2026-11-25, "so satisfying und juicy wie im Video, noch besser"): Woodcoins/XP schießen als Fontäne nach
// oben aus dem Block (BURST, mit Schwerkraft-Bogen und Münz-Überschlag), holen kurz aus (HANG, gegen die Flugrichtung) und
// werden dann stark beschleunigt zur Anzeige gesogen (FLY, mit Bewegungsschweif = in Flugrichtung gestrecktes Icon), wo sie
// hell aufblitzen (FLASH). HANG/FLY sind je Icon um 0-2 Ticks verschoben (startet versetzt), die Summe bleibt gleich:
// BURST 6 + HANG 2 + FLY 9 = Ankunft bei 17 - MUSS zu FlyFx.ARRIVE_TICKS passen, Ende 20 < REMOVE_AFTER_TICKS.
const float FLY_BURST = 6.0;
const float FLY_HANG = 2.0;
const float FLY_FLY = 9.0;
const float FLY_FLASH = 3.0;
// NEU (Wunsch 2026-11-19, "Holzblöcke sollen erst auf den Boden fallen und von dort eingesammelt werden"): eigener Ablauf
// für Holz (kind 0). MUSS zu FlyFx.ARRIVE_TICKS[WOOD] (= FALL + LIE + PICK) und REMOVE_AFTER_TICKS (> Ende) passen.
const float WOOD_FALL = 10.0;
const float WOOD_LIE = 4.0;
const float WOOD_PICK = 8.0;
const float WOOD_FLASH = 3.0;

float flyHash(float n) {
    return fract(sin(n * 12.9898 + 78.233) * 43758.5453);
}

float flyBack(float x) {
    float c1 = 1.70158;
    float c3 = c1 + 1.0;
    // GEÄNDERT (Bugfix 2026-11-25, Review): pow() mit negativer Basis ist in GLSL undefiniert und lieferte auf AMD-Karten
    // NaN - das Icon war in den ersten ~2,5 Ticks (genau der "springt groß heraus"-Moment) unsichtbar. Ausmultipliziert.
    float t = x - 1.0;
    return 1.0 + c3 * t * t * t + c1 * t * t;
}

void applyFly(inout vec4 pos, inout vec4 col, vec3 position) {
    ivec3 c = ivec3(round(col.rgb * 255.0));
    // GEÄNDERT (2026-11-25): G & 15 = 3 + style (FlyFx.STYLE_*, 0-5) - die Art der Bewegung reist in der Markierung mit.
    int style = (c.g & 15) - 3;
    if ((c.r & 15) != 12 || style < 0 || style > 5) return;
    // GEÄNDERT (2026-11-19, gemeldet "man sieht nichts"): Bildschirm aus der GESAMTEN Transformation (ProjMat x ModelViewMat) im
    // Raum von Position (= GUI-Pixel der Glyphen) - egal ob der Client die GUI-Skalierung in ProjMat oder ModelViewMat steckt.
    mat4 M = ProjMat * ModelViewMat;
    if (abs(M[3][3] - 1.0) > 0.001 || abs(M[2][3]) > 0.001 || abs(M[0][3]) > 0.001 || abs(M[1][3]) > 0.001) return;
    if (abs(M[0][0]) < 1e-6 || abs(M[1][1]) < 1e-6) return;
    int data = (c.r >> 4) | ((c.g >> 4) << 4) | (c.b << 8);
    int kind = data & 3;
    int spawn = (data >> 2) & 31;
    int payload = (data >> 7) & 511;
    float xL = (-1.0 - M[3][0]) / M[0][0];
    float xR = (1.0 - M[3][0]) / M[0][0];
    float yT0 = (1.0 - M[3][1]) / M[1][1];
    float yB0 = (-1.0 - M[3][1]) / M[1][1];
    // GEÄNDERT (Bugfix 2026-11-28, Spieler-Meldung "bei 26.2 sind die XP-Flug-Icons über Kopf"): 26.2 hat ein neues Grafik-
    // Backend, dort ist NDC +1 nicht zwingend der obere Bildschirmrand. GUI-Koordinaten (Position) zeigen in Minecraft aber
    // immer nach unten - oben ist deshalb einfach der kleinere Wert. Unter OpenGL ändert sich dadurch nichts (dort war es schon so).
    float yT = min(yT0, yB0);
    float yB = max(yT0, yB0);
    float left = min(xL, xR);
    float W = abs(xR - xL);
    float down = yB > yT ? 1.0 : -1.0;
    float H = abs(yB - yT);
    // GEÄNDERT (Bugfix 2026-11-19, gemeldet "Fluganimation, wenn ich im Inventar über ein Item hovere"): bunte Texte (z.B. die
    // animierten Crate-Namen) treffen die Farbmarkierung zufällig (~1/256 je Farbe). Echte Flug-Icons liegen immer weit unter
    // dem Bildschirm (Font-Ascent -2000) - normaler Text nie. Nur dann ist es wirklich ein Flug-Icon.
    if ((position.y - yB) * down < 1000.0) return;
    float age = mod(GameTime * 24000.0 - float(spawn), 32.0);
    vec2 C = vec2(left + W * 0.5, (yT + yB) * 0.5);
    vec2 T;
    float seed;
    // NEU (Wunsch 2026-11-20, "Holz soll da liegen, wo der Blitz langfliegt"): Holz mit Bit 8 im Payload hat eine Bildschirm-
    // Position vom Server (FlyFx.woodAt()): Bits 0-2 = x (Tangens-Raum / tan(FOV/2), -2,2..2,2, wird hier durch das
    // Seitenverhältnis geteilt), Bits 3-5 = y (NDC -1..1, oben positiv), Bits 6-7 = Zufall. Das Holz fällt dann dort statt aus
    // der Bildschirmmitte.
    bool aimed = kind == 0 && payload >= 256;
    vec2 C0 = C;
    if (aimed) {
        float xt = float(payload & 7) / 7.0 * 4.4 - 2.2;
        float yn = float((payload >> 3) & 7) / 7.0 * 2.0 - 1.0;
        float aspect = W / max(H, 1.0);
        C0 = vec2(C.x + clamp(xt / aspect, -0.92, 0.7) * W * 0.5, C.y - clamp(yn, -0.85, 0.85) * H * 0.5 * down);
    }
    if (kind == 0) {
        T = vec2(left + W * 0.5, yB - 92.0 * down); // knapp über dem Actionbar-Text (Mitte bei H-68), nicht darauf
        // GEÄNDERT (2026-11-25): Start-Tick immer im Seed - sonst flögen in einem großen Schwall Stücke mit gleichem
        // Zufallswert deckungsgleich.
        seed = float(payload) * 1.37 + float(spawn) * 5.71 + 3.0;
    } else {
        T = vec2(left + W - 3.0 - float((payload >> 5) & 15) * 14.0, C.y + float((payload & 31) - 22) * 4.0 * down);
        seed = float(spawn * 7 + kind * 131) + 0.5;
    }
    vec2 p;
    float scale;
    float alpha = 1.0;
    float glow = 0.0;
    float spinDir = flyHash(seed + 12.7) > 0.5 ? 1.0 : -1.0;
    float rot = 0.0;
    // NEU (2026-11-25): sc = Stauchen/Strecken in den Achsen des Icons (Aufprall-Squash, Münz-Überschlag);
    // smear = Strecken in Flugrichtung smearDir (Bewegungsschweif), das Icon selbst bleibt dabei aufrecht.
    vec2 sc = vec2(1.0);
    vec2 smearDir = vec2(1.0, 0.0);
    float smear = 1.0;
    float size = 0.9 + 0.22 * flyHash(seed + 21.3); // jedes Icon etwas anders groß - wirkt wie Tiefe
    if (kind == 0) {
        // Holz: im Bogen aus dem Block, überschlägt sich, fällt auf den "Boden" unter dem Fadenkreuz, federt zweimal nach,
        // holt kurz aus und wird dann eingesammelt (fliegt stark beschleunigt mit Schweif in die Actionbar).
        // NEU (Wunsch 2026-11-25, "bei besonderen Procs sollen die sich auch besonders bewegen"): style (FlyFx.STYLE_*) gibt
        // jeder Ability ihre eigene Bewegung, die Zeiten (FALL/LIE/PICK) bleiben für alle gleich:
        //   1 Lightning: zuckt beim Fallen und beim Einsammeln im Zickzack wie ein Blitz und flackert hell
        //   2 Titan:     wird hoch geschleudert, schlägt hart auf (starkes Plattdrücken, hohes Nachfedern), schwerer Sog
        //   3 Explosion: wird als Ring in alle Richtungen weggesprengt (doppelte Drehung), dann Trichter-Sog
        //   4 Forest:    Ring, der sich um die Mitte dreht und als Wirbel spiralförmig in die Actionbar zusammenfällt
        //   5 Glowing-Schauer: normale Bahn, pulsiert hell
        bool blast = style == 3 || style == 4;
        float ringA = flyHash(seed + 1.7) * 6.2832;
        float ringR = style == 4 ? 105.0 + flyHash(seed + 4.1) * 40.0 : 60.0 + flyHash(seed + 4.1) * 110.0;
        vec2 land = aimed
            ? vec2(C0.x + (flyHash(seed + 1.7) - 0.5) * 90.0, C0.y + (12.0 + flyHash(seed + 4.1) * 26.0) * down)
            : vec2(C.x + (flyHash(seed + 1.7) - 0.5) * 190.0, C.y + (46.0 + flyHash(seed + 4.1) * 40.0) * down);
        if (blast) {
            land = C0 + vec2(cos(ringA), sin(ringA) * 0.62) * ringR;
        }
        float hop = (26.0 + flyHash(seed + 6.3) * 26.0) * (style == 2 ? 2.3 : blast ? 0.35 : 1.0);
        float flicker = style == 1 ? 0.9 * step(0.5, fract(age * 0.8 + flyHash(seed + 3.3)))
            : style == 5 ? 0.5 + 0.5 * sin(age * 1.6 + flyHash(seed + 3.3) * 6.2832) : 0.0;
        if (age < WOOD_FALL) {
            float k = age / WOOD_FALL;
            float kx = blast ? 1.0 - pow(max(1.0 - k, 0.0), 3.0) : 1.0 - (1.0 - k) * (1.0 - k);
            float ky = blast ? kx : style == 2 ? k * k * k : k * k;
            p = vec2(mix(C0.x, land.x, kx), mix(C0.y, land.y, ky) - hop * 4.0 * k * (1.0 - k) * down);
            if (style == 1) {
                p.x += (flyHash(seed + floor(age / 1.5) * 3.1) - 0.5) * 30.0 * (1.0 - k); // Zickzack, am Boden wieder ruhig
            }
            float popK = min(1.0, k * 3.4);
            scale = (0.25 + 1.2 * flyBack(popK)) * mix(1.0, 0.69, smoothstep(0.3, 0.95, k)); // springt groß heraus, wird normal
            rot = spinDir * k * 6.2832 * (blast ? 2.0 : 1.0); // ganze Umdrehungen - landet aufrecht
            glow = 0.45 * (1.0 - popK) + flicker;
        } else if (age < WOOD_FALL + WOOD_LIE) {
            float k = (age - WOOD_FALL) / WOOD_LIE;
            float q = exp(-k * 4.5) * cos(k * 15.7);       // gedämpftes Nachfedern: erst platt, dann hoch, dann ruhig
            float ant = smoothstep(0.72, 1.0, k);          // Ausholen vor dem Einsammeln
            float squash = style == 2 ? 0.6 : 0.34;
            float bounce = style == 2 ? 2.2 : 1.0;
            p = land - vec2(0.0, (abs(sin(k * 6.2832)) * (1.0 - k) * (1.0 - k) * 14.0 * bounce + ant * 4.0) * down);
            sc = vec2(1.0 + squash * q - 0.12 * ant, 1.0 - squash * q + 0.16 * ant);
            scale = 1.0;
            rot = spinDir * 0.10 * q;
            glow = flicker;
            if (style == 4) {
                float th = ringA + 1.3 * k; // der Ring beginnt sich zu drehen
                p = C0 + vec2(cos(th), sin(th) * 0.62) * ringR - vec2(0.0, sin(k * 3.14159) * 6.0 * down);
                sc = vec2(1.0);
                rot = spinDir * 0.5 * k;
            }
        } else if (age < WOOD_FALL + WOOD_LIE + WOOD_PICK) {
            float k = (age - WOOD_FALL - WOOD_LIE) / WOOD_PICK;
            float e = pow(max(k, 0.0), style == 2 ? 3.0 : 2.1);
            if (style == 4) {
                // Wirbel: dreht sich weiter, wird enger und wandert dabei zur Actionbar
                float th = ringA + 1.3 + 4.2 * e;
                p = mix(C0, T, e) + vec2(cos(th), sin(th) * 0.62) * ringR * (1.0 - e);
                rot = spinDir * (0.5 + 5.7832 * e); // endet nach genau einer Umdrehung aufrecht
                scale = 1.0 - 0.2 * e;
                glow = 0.6 * e;
            } else {
                vec2 from = land - vec2(0.0, 4.0 * down);
                // GEÄNDERT (Wunsch 2026-11-25, "Flugrichtungen so cool wie möglich"): jedes Stück schwingt erst nach AUSSEN und
                // oben aus (links liegendes Holz nach links, rechts liegendes nach rechts) und stürzt dann in die Actionbar -
                // zusammen ergibt das einen Trichter, der sich von beiden Seiten schließt.
                float side = from.x >= T.x ? 1.0 : -1.0;
                vec2 ctrl = from + vec2(side * (46.0 + 60.0 * flyHash(seed + 8.8)), -(26.0 + 34.0 * flyHash(seed + 2.9)) * down);
                p = mix(mix(from, ctrl, e), mix(ctrl, T, e), e);
                vec2 dP = (1.0 - e) * (ctrl - from) + e * (T - ctrl);
                smearDir = dP / max(length(dP), 0.001);
                smear = 1.0 + 0.8 * smoothstep(0.25, 0.8, k);
                scale = 1.0 - 0.2 * e; // wird im Sog kleiner statt nur länger - bleibt als Holzstück erkennbar
                glow = 0.5 * e + flicker;
                if (style == 1) {
                    // Blitzbahn: springt quer zur Flugrichtung hin und her, zum Ziel hin immer weniger
                    p += vec2(-smearDir.y, smearDir.x) * (flyHash(seed + floor(k * 7.0) * 5.3) - 0.5) * 34.0 * (1.0 - e);
                }
            }
        } else if (age < WOOD_FALL + WOOD_LIE + WOOD_PICK + WOOD_FLASH) {
            float k = (age - WOOD_FALL - WOOD_LIE - WOOD_PICK) / WOOD_FLASH;
            p = T;
            scale = (style == 2 ? 2.5 : 2.0) - 1.1 * k; // Aufprall: sofort groß und hell, fällt dann zusammen (kein blasser Rest am Ziel)
            sc = vec2(1.0 + 0.35 * (1.0 - k), 1.0 - 0.3 * (1.0 - k)); // platscht breit auf
            alpha = 1.0 - k * k * k;
            glow = 2.4 * (1.0 - k * k);
        } else {
            pos = vec4(-10.0, -10.0, 0.0, 1.0);
            col = vec4(0.0);
            return;
        }
    } else {
        // Woodcoins / XP: Fontäne nach oben (Kegel +-70 Grad um die Senkrechte), Schwerkraft biegt die Bahn wieder nach unten.
        float a = (flyHash(seed + 1.7) - 0.5) * 2.5;
        float rad = 46.0 + flyHash(seed + 4.1) * 84.0;
        vec2 v = vec2(sin(a) * rad, -cos(a) * rad * down);
        float grav = 22.0 + flyHash(seed + 6.3) * 18.0;
        vec2 O = C - vec2(0.0, 10.0 * down); // startet knapp ÜBER dem Fadenkreuz, damit es beim Dauerhacken frei bleibt
        vec2 S = O + v + vec2(0.0, grav * down);
        float delay = flyHash(seed + 15.1) * 2.0;
        float hangT = FLY_HANG + delay;
        float flyT = FLY_FLY - delay;
        vec2 toT = T - S;
        float lenT = max(length(toT), 0.001);
        vec2 A = S - toT / lenT * 16.0; // Ausholpunkt: ein Stück vom Ziel WEG
        if (age < FLY_BURST) {
            float k = age / FLY_BURST;
            float o = 1.0 - pow(max(1.0 - k, 0.0), 2.4);
            p = O + v * o + vec2(0.0, grav * k * k * down);
            scale = flyBack(min(1.0, age / 2.4)) * mix(2.0, 1.15, smoothstep(0.25, 1.0, k));
            glow = 0.6 * (1.0 - k);
            if (kind == 1) {
                sc.x = max(0.16, abs(cos(k * 9.4248))); // Münze überschlägt sich 1,5-mal und liegt am Ende flach
            } else {
                rot = spinDir * (1.0 - k) * (1.0 - k) * 0.5; // nur leicht schräg - "XP" bleibt lesbar
            }
        } else if (age < FLY_BURST + hangT) {
            float k = (age - FLY_BURST) / hangT;
            float w = sin(k * 1.5708);
            p = mix(S, A, w);
            sc = vec2(1.0 + 0.2 * w, 1.0 - 0.2 * w);
            scale = 1.15;
        } else if (age < FLY_BURST + hangT + flyT) {
            float k = (age - FLY_BURST - hangT) / flyT;
            float e = pow(max(k, 0.0), 1.9);
            vec2 d = T - A;
            float len = max(length(d), 0.001);
            vec2 n = vec2(-d.y, d.x) / len;
            if (n.y * down > 0.0) n = -n; // Bogen immer nach OBEN, unterschiedlich stark gewölbt - ein aufgefächerter Strom
            vec2 ctrl = A + d * 0.3 + n * len * (0.2 + 0.24 * flyHash(seed + 9.3));
            p = mix(mix(A, ctrl, e), mix(ctrl, T, e), e);
            // NEU (Wunsch 2026-11-25, "Flugrichtungen so cool wie möglich"): die Icons schlängeln sich um ihre Bahn (anderthalb
            // Wellen, jedes mit eigenem Takt) - der Strom wirkt wie ein lebendiges Band. Am Start und am Ziel ist der
            // Ausschlag 0, es gibt also keinen Sprung.
            p += n * sin(e * 9.4248 + flyHash(seed + 17.9) * 6.2832) * 11.0 * sin(e * 3.14159);
            vec2 dP = (1.0 - e) * (ctrl - A) + e * (T - ctrl);
            smearDir = dP / max(length(dP), 0.001);
            smear = 1.0 + (kind == 1 ? 0.7 : 0.35) * smoothstep(0.3, 0.8, k); // Schrift verträgt kaum Streckung
            scale = 1.15 - 0.3 * e;
            glow = 0.55 * e;
        } else if (age < FLY_BURST + FLY_HANG + FLY_FLY + FLY_FLASH) {
            float k = (age - FLY_BURST - FLY_HANG - FLY_FLY) / FLY_FLASH;
            p = T;
            scale = 1.45 - 0.7 * k; // sofort groß und hell, fällt dann zusammen; klein genug fürs Scoreboard daneben
            alpha = 1.0 - k * k * k;
            glow = 2.4 * (1.0 - k * k);
        } else {
            pos = vec4(-10.0, -10.0, 0.0, 1.0);
            col = vec4(0.0);
            return;
        }
    }
    int corner = gl_VertexID % 4;
    vec2 off = vec2(corner >= 2 ? 0.5 : -0.5, ((corner == 1 || corner == 2) ? 0.5 : -0.5) * down) * sc;
    float cs = cos(rot);
    float sn = sin(rot);
    off = vec2(off.x * cs - off.y * sn, off.x * sn + off.y * cs);
    vec2 smearPerp = vec2(-smearDir.y, smearDir.x);
    off = smearDir * dot(off, smearDir) * smear + smearPerp * dot(off, smearPerp) * mix(1.0, 0.86, clamp(smear - 1.0, 0.0, 1.0));
    // GEÄNDERT (Wunsch 2026-11-19, "XP etwas kleiner"): XP-Icons 75 % der normalen Größe
    // GEÄNDERT (Wunsch 2026-11-19, "Woodcoins kleiner"): Woodcoins 80 %; kind 3 = zweite XP-Variante (FlyFx.XP_ALT), gleiche Größe wie XP
    vec2 g = p + off * FLY_SIZE * scale * size * (kind >= 2 ? 0.75 : kind == 1 ? 0.8 : 1.0);
    pos = M * vec4(g, position.z, 1.0);
    col = vec4(vec3(1.12 + glow * 0.7), alpha);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vec4 fxColor = Color;
    applyFly(gl_Position, fxColor, Position);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = animateMarked(fxColor, gl_Position) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
