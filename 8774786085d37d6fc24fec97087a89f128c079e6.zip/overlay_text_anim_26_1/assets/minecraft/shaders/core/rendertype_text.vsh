#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

vec3 loop2(vec3 a, vec3 b, float t) {
    float p = fract(t) * 2.0;
    return p < 1.0 ? mix(a, b, p) : mix(b, a, p - 1.0);
}

vec3 loop3(vec3 a, vec3 b, vec3 c, float t) {
    float p = fract(t) * 3.0;
    if (p < 1.0) return mix(a, b, p);
    if (p < 2.0) return mix(b, c, p - 1.0);
    return mix(c, a, p - 2.0);
}

vec3 animatedColor(int id, float t) {
    if (id == 1) return hsv2rgb(vec3(fract(t), 0.85, 1.00));
    if (id == 2) return loop2(vec3(0.0000, 0.9412, 1.0000), vec3(1.0000, 0.0000, 0.8980), t);
    if (id == 3) return loop3(vec3(1.0000, 0.1647, 0.0000), vec3(1.0000, 0.6039, 0.0000), vec3(1.0000, 0.8824, 0.3020), t);
    if (id == 4) return loop3(vec3(1.0000, 1.0000, 1.0000), vec3(0.6078, 0.9059, 1.0000), vec3(0.2471, 0.6627, 1.0000), t);
    if (id == 5) return loop3(vec3(0.5412, 0.1686, 0.8863), vec3(1.0000, 0.4314, 0.7804), vec3(1.0000, 0.8431, 0.4314), t);
    if (id == 6) return loop3(vec3(0.7843, 0.5882, 0.1176), vec3(1.0000, 0.8863, 0.4784), vec3(1.0000, 1.0000, 1.0000), t);
    if (id == 7) return loop3(vec3(0.4824, 0.1843, 0.9686), vec3(0.7843, 0.4275, 0.8431), vec3(0.0000, 0.8314, 1.0000), t);
    if (id == 8) return loop3(vec3(0.2235, 1.0000, 0.0784), vec3(0.7137, 1.0000, 0.0000), vec3(0.0000, 1.0000, 0.6118), t);
    if (id == 9) return loop3(vec3(0.5451, 0.0000, 0.0000), vec3(1.0000, 0.1255, 0.1255), vec3(1.0000, 0.4824, 0.4824), t);
    if (id == 10) return loop3(vec3(0.8784, 1.0000, 0.9804), vec3(0.4314, 0.9059, 0.8471), vec3(0.1216, 0.6353, 0.6353), t);
    if (id == 11) return hsv2rgb(vec3(fract(t), 0.45, 1.00));
    if (id == 12) return loop3(vec3(1.0000, 1.0000, 1.0000), vec3(1.0000, 0.9490, 0.0000), vec3(0.0000, 0.7020, 1.0000), t);
    return vec3(1.0);
}

vec4 animateMarked(vec4 color, vec4 clipPos) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    int id = c.b & 15;
    // GEÄNDERT (Bugfix 2026-10-16, gemeldet "Bugs bei Blood Moon" - gelbe/orange Flecken an einzelnen Buchstaben): der
    // Textschatten (Farbe x 0,25) traf bei ~2-15 % der Buchstaben zufällig selbst die Markierung, oft mit einer anderen
    // Stil-ID, und wurde dann bunt gefärbt. Schatten haben je Kanal höchstens 63, echte markierte Farben immer einen
    // Kanal >= 64 (alle Stil-Farben sind hell genug) - deshalb nur noch darüber.
    if ((c.r & 15) == 10 && (c.g & 15) == 5 && id >= 1 && id <= 12 && max(c.r, max(c.g, c.b)) >= 64) {
        float phase = fract(GameTime * 1200.0 / 3.0);
        float x = clipPos.x / max(clipPos.w, 0.0001);
        color.rgb = animatedColor(id, x * 1.5 - phase);
    }
    return color;
}

const float FLY_SIZE = 14.0;
const float FLY_POP = 4.0;
const float FLY_HANG = 3.0;
const float FLY_FLY = 10.0;
const float FLY_FLASH = 4.0;
// NEU (Wunsch 2026-11-19, "Holzblöcke sollen erst auf den Boden fallen und von dort eingesammelt werden"): eigener Ablauf
// für Holz (kind 0). MUSS zu FlyFx.ARRIVE_TICKS[WOOD] (= FALL + LIE + PICK) und REMOVE_AFTER_TICKS (> Ende) passen.
const float WOOD_FALL = 10.0;
const float WOOD_LIE = 4.0;
const float WOOD_PICK = 8.0;
const float WOOD_FLASH = 3.0;

float flyHash(float n) {
    return fract(sin(n * 12.9898 + 78.233) * 43758.5453);
}

float flyBack(float x) {
    float c1 = 1.70158;
    float c3 = c1 + 1.0;
    return 1.0 + c3 * pow(x - 1.0, 3.0) + c1 * pow(x - 1.0, 2.0);
}

void applyFly(inout vec4 pos, inout vec4 col, vec3 position) {
    ivec3 c = ivec3(round(col.rgb * 255.0));
    if ((c.r & 15) != 12 || (c.g & 15) != 3) return;
    // GEÄNDERT (2026-11-19, gemeldet "man sieht nichts"): Bildschirm aus der GESAMTEN Transformation (ProjMat x ModelViewMat) im
    // Raum von Position (= GUI-Pixel der Glyphen) - egal ob der Client die GUI-Skalierung in ProjMat oder ModelViewMat steckt.
    mat4 M = ProjMat * ModelViewMat;
    if (abs(M[3][3] - 1.0) > 0.001 || abs(M[2][3]) > 0.001 || abs(M[0][3]) > 0.001 || abs(M[1][3]) > 0.001) return;
    if (abs(M[0][0]) < 1e-6 || abs(M[1][1]) < 1e-6) return;
    int data = (c.r >> 4) | ((c.g >> 4) << 4) | (c.b << 8);
    int kind = data & 3;
    int spawn = (data >> 2) & 31;
    int payload = (data >> 7) & 511;
    float xL = (-1.0 - M[3][0]) / M[0][0];
    float xR = (1.0 - M[3][0]) / M[0][0];
    float yT = (1.0 - M[3][1]) / M[1][1];
    float yB = (-1.0 - M[3][1]) / M[1][1];
    float left = min(xL, xR);
    float W = abs(xR - xL);
    float down = yB > yT ? 1.0 : -1.0;
    float H = abs(yB - yT);
    // GEÄNDERT (Bugfix 2026-11-19, gemeldet "Fluganimation, wenn ich im Inventar über ein Item hovere"): bunte Texte (z.B. die
    // animierten Crate-Namen) treffen die Farbmarkierung zufällig (~1/256 je Farbe). Echte Flug-Icons liegen immer weit unter
    // dem Bildschirm (Font-Ascent -2000) - normaler Text nie. Nur dann ist es wirklich ein Flug-Icon.
    if ((position.y - yB) * down < 1000.0) return;
    float age = mod(GameTime * 24000.0 - float(spawn), 32.0);
    vec2 C = vec2(left + W * 0.5, (yT + yB) * 0.5);
    vec2 T;
    float seed;
    // NEU (Wunsch 2026-11-20, "Holz soll da liegen, wo der Blitz langfliegt"): Holz mit Bit 8 im Payload hat eine Bildschirm-
    // Position vom Server (FlyFx.woodAt()): Bits 0-2 = x (Tangens-Raum / tan(FOV/2), -2,2..2,2, wird hier durch das
    // Seitenverhältnis geteilt), Bits 3-5 = y (NDC -1..1, oben positiv), Bits 6-7 = Zufall. Das Holz fällt dann dort statt aus
    // der Bildschirmmitte.
    bool aimed = kind == 0 && payload >= 256;
    vec2 C0 = C;
    if (aimed) {
        float xt = float(payload & 7) / 7.0 * 4.4 - 2.2;
        float yn = float((payload >> 3) & 7) / 7.0 * 2.0 - 1.0;
        float aspect = W / max(H, 1.0);
        C0 = vec2(C.x + clamp(xt / aspect, -0.92, 0.92) * W * 0.5, C.y - clamp(yn, -0.85, 0.85) * H * 0.5 * down);
    }
    if (kind == 0) {
        T = vec2(left + W * 0.5, yB - 84.0 * down); // knapp über dem Actionbar-Text (Mitte bei H-68), nicht darauf
        seed = aimed ? float(payload) * 1.37 + float(spawn) * 5.71 + 3.0 : float(payload) * 1.37 + 3.0;
    } else {
        T = vec2(left + W - 3.0 - float((payload >> 5) & 15) * 14.0, C.y + float((payload & 31) - 22) * 4.0 * down);
        seed = float(spawn * 7 + kind * 131) + 0.5;
    }
    float ang = flyHash(seed + 1.7) * 6.2832;
    float rad = 24.0 + flyHash(seed + 4.1) * 26.0;
    vec2 S = C + vec2(cos(ang), sin(ang) * 0.75 * down) * rad;
    vec2 p;
    float scale;
    float alpha = 1.0;
    float glow = 0.0;
    // GEÄNDERT (Wunsch 2026-11-19, "knalliger und mehr satisfying"): stärkerer Pop mit Überschwingen + Dreh-Schwung,
    // Wackeln beim Schweben, gerade Ausrichtung im Flug, kräftigere Farben und ein heller Ankunfts-Blitz.
    float spinDir = flyHash(seed + 12.7) > 0.5 ? 1.0 : -1.0;
    float rot = 0.0;
    if (kind == 0) {
        // Holz: im Bogen aus dem Block, überschlägt sich, fällt auf den "Boden" unter dem Fadenkreuz, hüpft kurz,
        // bleibt liegen und wird dann eingesammelt (fliegt beschleunigt in die Actionbar).
        vec2 land = aimed
            ? vec2(C0.x + (flyHash(seed + 1.7) - 0.5) * 90.0, C0.y + (12.0 + flyHash(seed + 4.1) * 26.0) * down)
            : vec2(C.x + (flyHash(seed + 1.7) - 0.5) * 150.0, C.y + (50.0 + flyHash(seed + 4.1) * 30.0) * down);
        float hop = 22.0 + flyHash(seed + 6.3) * 16.0;
        if (age < WOOD_FALL) {
            float k = age / WOOD_FALL;
            p = vec2(mix(C0.x, land.x, k), mix(C0.y, land.y, k * k) - hop * 4.0 * k * (1.0 - k) * down);
            scale = 0.35 + 0.65 * min(1.0, k * 3.0);
            rot = spinDir * k * 6.2832; // genau eine Umdrehung - landet aufrecht
        } else if (age < WOOD_FALL + WOOD_LIE) {
            float k = (age - WOOD_FALL) / WOOD_LIE;
            p = land - vec2(0.0, abs(sin(k * 3.14159)) * (1.0 - k) * 7.0 * down);
            scale = 1.0 + 0.12 * (1.0 - k) * sin(k * 9.42);
            rot = spinDir * 0.12 * sin(k * 9.42) * (1.0 - k);
        } else if (age < WOOD_FALL + WOOD_LIE + WOOD_PICK) {
            float k = (age - WOOD_FALL - WOOD_LIE) / WOOD_PICK;
            float e = k * k * k;
            vec2 d = T - land;
            vec2 ctrl = land + vec2(d.x * 0.2, -30.0 * down);
            p = mix(mix(land, ctrl, e), mix(ctrl, T, e), e);
            scale = 1.0 - 0.2 * e;
            glow = 0.3 * e;
        } else if (age < WOOD_FALL + WOOD_LIE + WOOD_PICK + WOOD_FLASH) {
            float k = (age - WOOD_FALL - WOOD_LIE - WOOD_PICK) / WOOD_FLASH;
            p = T;
            scale = 0.8 + 0.5 * k;
            alpha = 1.0 - k * k;
            glow = 1.6 * (1.0 - k);
        } else {
            pos = vec4(-10.0, -10.0, 0.0, 1.0);
            col = vec4(0.0);
            return;
        }
    } else if (age < FLY_POP) {
        float k = age / FLY_POP;
        float e = flyBack(k);
        p = mix(C, S, e);
        scale = 0.15 + 1.25 * e;
        rot = spinDir * (1.0 - k) * 1.2;
        glow = 0.5 * (1.0 - k);
    } else if (age < FLY_POP + FLY_HANG) {
        float k = (age - FLY_POP) / FLY_HANG;
        p = S + vec2(0.0, -2.5 * down * sin(k * 3.14159));
        scale = 1.25 - 0.25 * k + 0.08 * sin(k * 6.2832);
        rot = spinDir * 0.18 * sin(k * 6.2832);
    } else if (age < FLY_POP + FLY_HANG + FLY_FLY) {
        float k = (age - FLY_POP - FLY_HANG) / FLY_FLY;
        float e = k * k * k;
        vec2 d = T - S;
        float len = max(length(d), 0.001);
        vec2 n = vec2(-d.y, d.x) / len * (flyHash(seed + 9.3) > 0.5 ? 1.0 : -1.0);
        vec2 ctrl = S + d * 0.35 + n * len * 0.25;
        p = mix(mix(S, ctrl, e), mix(ctrl, T, e), e);
        scale = 1.0 - 0.25 * e;
    } else if (age < FLY_POP + FLY_HANG + FLY_FLY + FLY_FLASH) {
        float k = (age - FLY_POP - FLY_HANG - FLY_FLY) / FLY_FLASH;
        p = T;
        scale = 0.75 + 0.55 * k; // Ankunfts-Blitz wächst nur leicht, damit er nicht in Scoreboard/Actionbar ragt
        alpha = 1.0 - k * k;
        glow = 1.6 * (1.0 - k);
    } else {
        pos = vec4(-10.0, -10.0, 0.0, 1.0);
        col = vec4(0.0);
        return;
    }
    int corner = gl_VertexID % 4;
    vec2 off = vec2(corner >= 2 ? 0.5 : -0.5, ((corner == 1 || corner == 2) ? 0.5 : -0.5) * down);
    float cs = cos(rot);
    float sn = sin(rot);
    off = vec2(off.x * cs - off.y * sn, off.x * sn + off.y * cs);
    // GEÄNDERT (Wunsch 2026-11-19, "XP etwas kleiner"): XP-Icons 75 % der normalen Größe
    // GEÄNDERT (Wunsch 2026-11-19, "Woodcoins kleiner"): Woodcoins 80 %; kind 3 = zweite XP-Variante (FlyFx.XP_ALT), gleiche Größe wie XP
    vec2 g = p + off * FLY_SIZE * scale * (kind >= 2 ? 0.75 : kind == 1 ? 0.8 : 1.0);
    pos = M * vec4(g, position.z, 1.0);
    col = vec4(vec3(1.12 + glow * 0.7), alpha);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vec4 fxColor = Color;
    applyFly(gl_Position, fxColor, Position);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = animateMarked(fxColor, gl_Position) * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
